<?php
 echo 5*7;
 ?>